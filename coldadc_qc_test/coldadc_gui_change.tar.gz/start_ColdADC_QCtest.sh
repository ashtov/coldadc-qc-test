#!/bin/bash

python3 gui_new.py
